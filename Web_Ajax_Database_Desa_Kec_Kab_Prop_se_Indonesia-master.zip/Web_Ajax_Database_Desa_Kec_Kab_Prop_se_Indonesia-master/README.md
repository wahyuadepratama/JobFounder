Web_Ajax_Database_Desa_Kec_Kab_Prop_se_Indonesia
================================================

Contoh Aplikasi Web Untuk Memilih Lokasi disertai Database Lokasi se Indonesia

View my blog post : http://herupurwito.wordpress.com/2013/01/25/database-desa-kecamatan-kabupatenkota-dan-provinsi-se-indonesia-ajax/
